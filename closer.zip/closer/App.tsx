import React, { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, FlatList, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider, useSafeAreaInsets } from "react-native-safe-area-context";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";
import { manipulateAsync, SaveFormat } from "expo-image-manipulator";
import { useFonts } from "expo-font";
import { Inter_400Regular, Inter_500Medium } from "@expo-google-fonts/inter";
import { PlusJakartaSans_600SemiBold, PlusJakartaSans_700Bold, PlusJakartaSans_800ExtraBold } from "@expo-google-fonts/plus-jakarta-sans";
import ModelRunner, { ModelRunnerHandle } from "./src/ModelRunner";

/* ---------- tokens (Fase 4) ---------- */
const C = {
  bg: "#09090b", bg2: "#000000", card: "#18181b", fg: "#ffffff", fg2: "#a1a1aa", fg3: "#e4e4e7",
  line: "rgba(255,255,255,0.07)", accent: "#2563eb", accentHi: "#60a5fa", accentSoft: "rgba(37,99,235,0.16)",
  ok: "#22c55e", warn: "#f59e0b", err: "#ef4444",
};
const F = { b: "Inter_400Regular", bm: "Inter_500Medium", d6: "PlusJakartaSans_600SemiBold", d7: "PlusJakartaSans_700Bold", d8: "PlusJakartaSans_800ExtraBold" };

/* ---------- datos ---------- */
const DEFAULT_MODEL = "https://teachablemachine.withgoogle.com/models/9_hWn5f8d/";
const SITE = "https://fmendezsara.github.io/closer-4/images/";
const IMG = { logo: SITE + "logo.png", hero: SITE + "hero_visual.webp", polera: SITE + "demo-polera.webp", camisa: SITE + "demo-camisa.webp", pantalon: SITE + "demo-pantalon.webp", inventario: SITE + "service_5.webp" };
const CATS = ["Camisa formal", "Jeans", "Hoodie", "Otra prenda"] as const;
type Cat = (typeof CATS)[number];
const FILTERS: { label: string; cat?: Cat }[] = [
  { label: "Todas" }, { label: "Camisas", cat: "Camisa formal" }, { label: "Jeans", cat: "Jeans" }, { label: "Hoodies", cat: "Hoodie" }, { label: "Otras", cat: "Otra prenda" },
];
type Item = { id: number; name: string; cat: Cat; img?: string; ok: boolean; example?: boolean };
type Draft = { img: string; cat: Cat; suggested: Cat; conf: number | null; demo: boolean };
type Screen = "inicio" | "escanear" | "revisar" | "catalogo" | "detalle" | "ajustes";

const seed = (): Item[] => [
  { id: 1, name: "Camisa formal 01", cat: "Camisa formal", img: IMG.camisa, ok: true, example: true },
  { id: 2, name: "Pantalón 01", cat: "Jeans", img: IMG.pantalon, ok: true, example: true },
  { id: 3, name: "Polera 01", cat: "Otra prenda", img: IMG.polera, ok: false, example: true },
];
const TINT: Record<Cat, string> = { "Camisa formal": "#dbe4f3", Jeans: "#2f4f8f", Hoodie: "#4b5563", "Otra prenda": "#3f3f46" };

function normLabel(l: string): Cat {
  const s = l.toLowerCase();
  if (s.includes("jean") || s.includes("pantal")) return "Jeans";
  if (s.includes("hood") || s.includes("sudadera") || s.includes("polerón") || s.includes("poleron")) return "Hoodie";
  if (s.includes("camis") || s.includes("shirt")) return "Camisa formal";
  return "Otra prenda";
}

/* ---------- componentes base ---------- */
const Btn = ({ label, onPress, kind = "p", disabled }: { label: string; onPress: () => void; kind?: "p" | "s" | "t" | "d"; disabled?: boolean }) => (
  <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress}
    style={({ pressed }) => [s.btn, kind === "p" && s.btnP, kind === "s" && s.btnS, kind === "d" && s.btnD, kind === "t" && s.btnT, pressed && { transform: [{ scale: 0.97 }] }, disabled && { opacity: 0.45 }]}>
    <Text style={[s.btnTx, kind === "s" && { color: C.accentHi }, kind === "t" && { color: C.accentHi, fontSize: 15 }, kind === "d" && { color: C.err }]}>{label}</Text>
  </Pressable>
);
const Chip = ({ label, on, onPress }: { label: string; on: boolean; onPress: () => void }) => (
  <Pressable accessibilityRole="button" accessibilityState={{ selected: on }} onPress={onPress} style={[s.chip, on && s.chipOn]}>
    <Text style={[s.chipTx, on && { color: "#fff" }]}>{label}</Text>
  </Pressable>
);
const Badge = ({ ok }: { ok: boolean }) => (
  <View style={s.badge}><View style={[s.dot, { backgroundColor: ok ? C.ok : C.warn }]} /><Text style={s.muted2}>{ok ? "Revisada por ti" : "Pendiente de revisión"}</Text></View>
);
const Thumb = ({ item, style }: { item: { img?: string; cat: Cat }; style?: object }) =>
  item.img ? <Image source={{ uri: item.img }} style={[{ width: "100%", height: "100%" }, style]} /> : (
    <View style={[{ width: "100%", height: "100%", alignItems: "center", justifyContent: "center", backgroundColor: TINT[item.cat] }, style]}>
      <Text style={{ fontFamily: F.d8, fontSize: 40, color: item.cat === "Camisa formal" ? "#2f4f8f" : "#fff" }}>{item.cat[0]}</Text>
    </View>
  );
const Logo = ({ size = 28 }: { size?: number }) => (
  <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
    <Image source={{ uri: IMG.logo }} style={{ width: size, height: size }} resizeMode="contain" />
    <Text style={[s.logo, { fontSize: size * 0.8 }]}>Closer<Text style={{ color: C.accentHi }}>.</Text></Text>
  </View>
);

/* ---------- onboarding ---------- */
const OB = [
  { img: IMG.hero, t: "Una foto, una categoría", d: "Saca una foto a la prenda y Closer te sugiere si es camisa formal, jeans o hoodie." },
  { img: IMG.polera, t: "Tú decides", d: "La app sugiere, tú confirmas o corriges con un toque. Nada se guarda sin tu visto bueno." },
  { img: IMG.inventario, t: "Catálogo ordenado", d: "Todas tus prendas en un lugar, filtradas por categoría, listas para publicar el mismo día." },
];

function Root() {
  const insets = useSafeAreaInsets();
  const [fontsOk] = useFonts({ Inter_400Regular, Inter_500Medium, PlusJakartaSans_600SemiBold, PlusJakartaSans_700Bold, PlusJakartaSans_800ExtraBold });
  const [boot, setBoot] = useState(true);
  const [onb, setOnb] = useState<number | null>(null);
  const [screen, setScreen] = useState<Screen>("inicio");
  const [items, setItems] = useState<Item[]>(seed());
  const [filter, setFilter] = useState(0);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [loading, setLoading] = useState(false);
  const [detailId, setDetailId] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [confirmDel, setConfirmDel] = useState(false);
  const [toast, setToast] = useState("");
  const [modelUrl, setModelUrl] = useState("");
  const [modelInput, setModelInput] = useState("");
  const [modelStatus, setModelStatus] = useState<"none" | "loading" | "ready" | "error">("none");
  const runner = useRef<ModelRunnerHandle>(null);

  useEffect(() => {
    (async () => {
      try {
        const [it, ob, mu] = await Promise.all([AsyncStorage.getItem("closer.items"), AsyncStorage.getItem("closer.onb"), AsyncStorage.getItem("closer.model")]);
        if (it) setItems(JSON.parse(it));
        const url = mu ?? DEFAULT_MODEL;
        if (url) { setModelUrl(url); setModelInput(url); setModelStatus("loading"); }
        setOnb(ob ? -1 : 0);
      } catch { setOnb(0); }
      setTimeout(() => setBoot(false), 900);
    })();
  }, []);

  const persist = useCallback((next: Item[]) => { setItems(next); AsyncStorage.setItem("closer.items", JSON.stringify(next)).catch(() => {}); }, []);
  const say = (m: string) => { setToast(m); setTimeout(() => setToast(""), 3000); };
  const go = (sc: Screen) => { setConfirmDel(false); setScreen(sc); };
  const pending = items.filter((i) => !i.ok).length;

  async function handlePicked(res: ImagePicker.ImagePickerResult) {
    if (res.canceled || !res.assets?.length) return;
    setLoading(true);
    try {
      const out = await manipulateAsync(res.assets[0].uri, [{ resize: { width: 480 } }], { compress: 0.7, format: SaveFormat.JPEG, base64: true });
      const b64 = out.base64 ?? "";
      let cat: Cat; let conf: number | null = null; let demo = true;
      if (modelStatus === "ready" && runner.current) {
        try { const p = await runner.current.classify(b64); cat = normLabel(p.label); conf = p.prob; demo = false; }
        catch { cat = CATS[b64.length % 3]; }
      } else {
        await new Promise((r) => setTimeout(r, 800));
        cat = CATS[b64.length % 3];
      }
      setDraft({ img: "data:image/jpeg;base64," + b64, cat, suggested: cat, conf, demo });
      setScreen("revisar");
    } catch {
      Alert.alert("No pudimos leer la foto", "Prueba con otra imagen.");
    }
    setLoading(false);
  }
  async function camera() {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) { Alert.alert("Permiso de cámara", "Activa la cámara para Closer en los ajustes del teléfono, o elige una foto de la galería."); return; }
    handlePicked(await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], quality: 0.8 }));
  }
  async function gallery() { handlePicked(await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.8 })); }

  function nextName(cat: Cat) { return `${cat} ${String(items.filter((i) => i.cat === cat).length + 1).padStart(2, "0")}`; }
  function confirmSave() {
    if (!draft) return;
    persist([{ id: Date.now(), name: nextName(draft.cat), cat: draft.cat, img: draft.img, ok: true }, ...items]);
    setDraft(null); setFilter(0); setScreen("catalogo"); say("Prenda guardada en tu catálogo");
  }
  const open = (id: number) => { const it = items.find((i) => i.id === id); if (!it) return; setDetailId(id); setName(it.name); go("detalle"); };
  const detail = items.find((i) => i.id === detailId);

  function saveModel() {
    const u = modelInput.trim();
    AsyncStorage.setItem("closer.model", u).catch(() => {});
    setModelUrl(u); setModelStatus(u ? "loading" : "none"); say(u ? "Cargando modelo…" : "Modelo quitado, modo demostración");
  }

  if (!fontsOk || boot || onb === null) {
    return <View style={[s.fill, { alignItems: "center", justifyContent: "center" }]}><Logo size={56} /></View>;
  }

  if (onb >= 0) {
    const o = OB[onb];
    const finish = () => { AsyncStorage.setItem("closer.onb", "1").catch(() => {}); setOnb(-1); };
    return (
      <View style={[s.fill, { paddingTop: insets.top + 16, paddingBottom: insets.bottom + 16, paddingHorizontal: 20, justifyContent: "space-between" }]}>
        <View style={{ alignItems: "flex-end" }}><Btn kind="t" label="Saltar" onPress={finish} /></View>
        <View style={{ alignItems: "center", gap: 12 }}>
          <Image source={{ uri: o.img }} style={s.obArt} resizeMode="cover" />
          <Text style={[s.t1, { textAlign: "center" }]}>{o.t}</Text>
          <Text style={[s.muted, { textAlign: "center", fontSize: 16 }]}>{o.d}</Text>
        </View>
        <View style={{ gap: 20 }}>
          <View style={{ flexDirection: "row", gap: 6, justifyContent: "center" }}>{OB.map((_, i) => <View key={i} style={[s.pg, i === onb && s.pgOn]} />)}</View>
          <Btn label={onb === 2 ? "Comenzar" : "Siguiente"} onPress={() => (onb === 2 ? finish() : setOnb(onb + 1))} />
        </View>
        <StatusBar style="light" />
      </View>
    );
  }

  const list = items.filter((i) => !FILTERS[filter].cat || i.cat === FILTERS[filter].cat);
  const card = (i: Item) => (
    <Pressable key={i.id} onPress={() => open(i.id)} style={s.item} accessibilityRole="button" accessibilityLabel={i.name}>
      <View style={{ aspectRatio: 1, backgroundColor: C.bg2 }}><Thumb item={i} /></View>
      <View style={{ padding: 10, gap: 2 }}><Text numberOfLines={1} style={s.itemT}>{i.name}</Text><Badge ok={i.ok} /></View>
    </Pressable>
  );

  let body: React.ReactNode = null;
  if (screen === "inicio") {
    body = (
      <ScrollView contentContainerStyle={s.scr}>
        <View style={s.hdr}><Logo /><Pressable onPress={() => go("ajustes")} style={s.iconBtn} accessibilityLabel="Ajustes"><Text style={{ color: C.fg, fontSize: 20 }}>⚙</Text></Pressable></View>
        <View><Text style={s.over}>VISIÓN ARTIFICIAL PARA TU INVENTARIO</Text><Text style={[s.t1, { marginTop: 4 }]}>Cada prenda en su lugar, <Text style={{ color: C.accentHi }}>automáticamente.</Text></Text></View>
        <Image source={{ uri: IMG.hero }} style={{ width: "100%", aspectRatio: 1, borderRadius: 20, backgroundColor: C.card }} resizeMode="cover" />
        <Btn label="Escanear prenda" onPress={() => go("escanear")} />
        <View style={{ flexDirection: "row", gap: 8 }}>
          {[[items.length, "prendas"], [items.length - pending, "revisadas"], [pending, "pendientes"]].map(([n, l]) => (
            <View key={l as string} style={s.stat}><Text style={s.statN}>{n}</Text><Text style={s.muted2}>{l}</Text></View>
          ))}
        </View>
        {pending > 0 && (
          <View style={[s.card, { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }]}>
            <View style={{ flex: 1 }}><Text style={s.itemT}>Tienes {pending} por revisar</Text><Text style={s.muted2}>Confirma su categoría para dejarlas listas.</Text></View>
            <Btn kind="t" label="Ver" onPress={() => go("catalogo")} />
          </View>
        )}
        <Text style={s.t2}>Últimas prendas</Text>
        <View style={s.grid}>{items.slice(0, 4).map(card)}</View>
      </ScrollView>
    );
  } else if (screen === "escanear") {
    body = (
      <ScrollView contentContainerStyle={s.scr}>
        <View style={s.hdr}><Logo /><Text style={s.over}>VISIÓN ARTIFICIAL</Text></View>
        <View style={s.drop}>
          {loading ? (<><ActivityIndicator color={C.accentHi} size="large" /><Text style={[s.itemT, { marginTop: 12 }]}>Analizando la prenda…</Text></>) : (
            <><Text style={{ fontSize: 44 }}>📷</Text><Text style={[s.muted, { marginTop: 8 }]}>Ubica la prenda completa</Text></>
          )}
        </View>
        <View><Text style={s.t2}>Una foto, una categoría.</Text><Text style={[s.muted, { marginTop: 4 }]}>Buena luz y un fondo sencillo. La sugerencia siempre la confirmas tú.</Text></View>
        {modelStatus !== "ready" && (
          <View style={s.banner}><Text style={{ color: C.fg, fontFamily: F.b, fontSize: 13 }}>
            {modelStatus === "loading" ? "Cargando tu modelo de Teachable Machine…" : "Modo demostración: la categoría sugerida es de ejemplo. Pega la URL de tu modelo en Ajustes para usar el real."}</Text></View>
        )}
        <Btn label="Escanear prenda" onPress={camera} disabled={loading} />
        <Btn kind="s" label="Elegir de la galería" onPress={gallery} disabled={loading} />
      </ScrollView>
    );
  } else if (screen === "revisar") {
    if (!draft) body = <View style={s.scr}><Btn label="Tomar otra foto" onPress={() => go("escanear")} /></View>;
    else body = (
      <ScrollView contentContainerStyle={s.scr}>
        <View style={s.hdr}><Pressable onPress={() => go("escanear")} style={s.iconBtn} accessibilityLabel="Volver"><Text style={{ color: C.fg, fontSize: 20 }}>‹</Text></Pressable><Text style={s.over}>SUGERENCIA DE LA IA</Text><View style={{ width: 44 }} /></View>
        <View style={s.photo}><Image source={{ uri: draft.img }} style={{ width: "100%", height: "100%" }} resizeMode="cover" /></View>
        <View><Text style={s.muted}>{draft.demo ? "Sugerencia de ejemplo" : "Parece una"}</Text><Text style={s.sug}>{draft.suggested}</Text>{draft.conf != null && <Text style={s.muted}>Confianza {Math.round(draft.conf * 100)}%</Text>}</View>
        <View style={{ gap: 8 }}><Text style={[s.itemT, { fontSize: 15 }]}>¿Es correcta? Tú decides.</Text>
          <View style={s.chips}>{CATS.map((c) => <Chip key={c} label={c} on={draft.cat === c} onPress={() => setDraft({ ...draft, cat: c })} />)}</View></View>
        <Btn label="Confirmar y guardar" onPress={confirmSave} />
        <Btn kind="t" label="Tomar otra foto" onPress={() => go("escanear")} />
      </ScrollView>
    );
  } else if (screen === "catalogo") {
    body = (
      <View style={{ flex: 1 }}>
        <View style={{ paddingHorizontal: 16, paddingTop: 16, gap: 12 }}>
          <View style={[s.hdr, { alignItems: "flex-end" }]}><Text style={s.t1}>Tu catálogo</Text><Text style={s.muted2}>{items.length} prendas</Text></View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>{FILTERS.map((f, i) => <Chip key={f.label} label={f.label} on={filter === i} onPress={() => setFilter(i)} />)}</ScrollView>
        </View>
        <FlatList data={list} keyExtractor={(i) => String(i.id)} numColumns={2} columnWrapperStyle={{ gap: 12 }} contentContainerStyle={{ padding: 16, gap: 12 }}
          renderItem={({ item }) => <View style={{ flex: 1 }}>{card(item)}</View>}
          ListEmptyComponent={<View style={{ alignItems: "center", gap: 8, paddingVertical: 40 }}><Text style={s.t2}>Nada en esta categoría</Text><Text style={s.muted}>Escanea una prenda para empezar a llenarla.</Text><Btn kind="s" label="Escanear prenda" onPress={() => go("escanear")} /></View>} />
      </View>
    );
  } else if (screen === "detalle" && detail) {
    const upd = (p: Partial<Item>) => persist(items.map((i) => (i.id === detail.id ? { ...i, ...p } : i)));
    body = (
      <ScrollView contentContainerStyle={s.scr} keyboardShouldPersistTaps="handled">
        <View style={s.hdr}><Pressable onPress={() => go("catalogo")} style={s.iconBtn} accessibilityLabel="Volver"><Text style={{ color: C.fg, fontSize: 20 }}>‹</Text></Pressable><Text style={s.over}>FICHA DE PRENDA</Text><View style={{ width: 44 }} /></View>
        <View style={s.photo}><Thumb item={detail} /></View>
        {detail.example && <View style={s.banner}><Text style={{ color: C.fg, fontFamily: F.b, fontSize: 13 }}>Prenda de ejemplo para mostrar el catálogo. Puedes borrarla.</Text></View>}
        <View><Text style={[s.muted2, { marginBottom: 6 }]}>Nombre</Text><TextInput value={name} onChangeText={setName} style={s.input} placeholderTextColor={C.fg2} /></View>
        <View style={{ gap: 8 }}><Text style={s.muted2}>Categoría</Text><View style={s.chips}>{CATS.map((c) => <Chip key={c} label={c} on={detail.cat === c} onPress={() => upd({ cat: c, ok: true })} />)}</View></View>
        <Badge ok={detail.ok} />
        {!detail.ok && <Btn label="Marcar como revisada" onPress={() => { upd({ ok: true }); say("Marcada como revisada"); }} />}
        <Btn kind="s" label="Guardar cambios" onPress={() => { upd({ name: name.trim() || detail.name }); go("catalogo"); say("Cambios guardados"); }} />
        {confirmDel ? (
          <View style={s.card}><Text style={s.itemT}>¿Eliminar esta prenda?</Text><Text style={[s.muted2, { marginVertical: 6 }]}>No se puede deshacer.</Text>
            <View style={{ flexDirection: "row", gap: 8 }}><View style={{ flex: 1 }}><Btn kind="s" label="Cancelar" onPress={() => setConfirmDel(false)} /></View><View style={{ flex: 1 }}><Btn kind="d" label="Eliminar" onPress={() => { persist(items.filter((i) => i.id !== detail.id)); go("catalogo"); say("Prenda eliminada"); }} /></View></View></View>
        ) : <Btn kind="d" label="Eliminar prenda" onPress={() => setConfirmDel(true)} />}
      </ScrollView>
    );
  } else if (screen === "ajustes") {
    body = (
      <ScrollView contentContainerStyle={s.scr} keyboardShouldPersistTaps="handled">
        <View style={s.hdr}><Pressable onPress={() => go("inicio")} style={s.iconBtn} accessibilityLabel="Volver"><Text style={{ color: C.fg, fontSize: 20 }}>‹</Text></Pressable><Text style={s.t2}>Ajustes</Text><View style={{ width: 44 }} /></View>
        <View style={s.card}><Text style={s.itemT}>Camila Soto</Text><Text style={s.muted2}>Tienda de ropa · Concepción</Text></View>
        <View style={[s.card, { gap: 8 }]}>
          <Text style={s.itemT}>Modelo de Teachable Machine</Text>
          <Text style={s.muted2}>Pega el enlace de tu modelo exportado (termina en /models/XXXX/). Estado: {modelStatus === "ready" ? "cargado" : modelStatus === "loading" ? "cargando…" : modelStatus === "error" ? "no se pudo cargar" : "modo demostración"}.</Text>
          <TextInput value={modelInput} onChangeText={setModelInput} autoCapitalize="none" autoCorrect={false} placeholder="https://teachablemachine.withgoogle.com/models/…" placeholderTextColor={C.fg2} style={s.input} />
          <Btn kind="s" label="Guardar modelo" onPress={saveModel} />
        </View>
        <View style={[s.card, { gap: 8 }]}><Text style={s.itemT}>Datos</Text><Text style={s.muted2}>Tu catálogo se guarda solo en este teléfono.</Text>
          <Btn kind="d" label="Restaurar ejemplos y borrar mis prendas" onPress={() => { persist(seed()); go("inicio"); say("Catálogo restaurado"); }} /></View>
        <Text style={[s.muted2, { textAlign: "center" }]}>Closer · Autocatálogo IA · Curso Inteligencia Artificial, UDD</Text>
      </ScrollView>
    );
  }

  const tab = screen === "revisar" ? "escanear" : screen === "detalle" ? "catalogo" : screen;
  return (
    <View style={[s.fill, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <View style={{ flex: 1 }}>{body}</View>
      {!!toast && <View style={[s.toast, { bottom: 72 + insets.bottom }]}><Text style={{ color: C.bg, fontFamily: F.bm }}>{toast}</Text></View>}
      <View style={[s.tabs, { paddingBottom: insets.bottom }]}>
        {([["inicio", "⌂", "Inicio"], ["escanear", "◎", "Escanear"], ["catalogo", "▦", "Catálogo"]] as const).map(([k, g, l]) => (
          <Pressable key={k} onPress={() => go(k)} style={s.tab} accessibilityRole="tab" accessibilityLabel={l} accessibilityState={{ selected: tab === k }}>
            <Text style={{ fontSize: 22, color: tab === k ? C.accentHi : C.fg2 }}>{g}</Text>
            <Text style={{ fontFamily: F.bm, fontSize: 11, color: tab === k ? C.accentHi : C.fg2 }}>{l}</Text>
          </Pressable>
        ))}
      </View>
      {!!modelUrl && <ModelRunner key={modelUrl} ref={runner} modelUrl={modelUrl} onStatus={(st) => setModelStatus(st)} />}
    </View>
  );
}

export default function App() { return <SafeAreaProvider><Root /></SafeAreaProvider>; }

const s = StyleSheet.create({
  fill: { flex: 1, backgroundColor: C.bg },
  scr: { padding: 16, gap: 16 },
  hdr: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", minHeight: 44 },
  logo: { fontFamily: F.d8, fontSize: 22, color: C.fg, letterSpacing: -0.4 },
  over: { fontFamily: F.d6, fontSize: 11, letterSpacing: 0.9, color: C.accentHi },
  t1: { fontFamily: F.d8, fontSize: 30, lineHeight: 34, letterSpacing: -0.8, color: C.fg },
  t2: { fontFamily: F.d6, fontSize: 22, lineHeight: 28, color: C.fg },
  muted: { fontFamily: F.b, fontSize: 15, lineHeight: 22, color: C.fg2 },
  muted2: { fontFamily: F.b, fontSize: 13, color: C.fg2 },
  sug: { fontFamily: F.d8, fontSize: 34, lineHeight: 38, color: C.fg },
  btn: { height: 52, borderRadius: 12, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  btnP: { backgroundColor: C.accent, shadowColor: C.accent, shadowOpacity: 0.45, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 6 },
  btnS: { borderWidth: 1, borderColor: C.accent },
  btnD: { borderWidth: 1, borderColor: C.err },
  btnT: { minHeight: 44, height: undefined, alignSelf: "center" },
  btnTx: { fontFamily: F.d6, fontSize: 16, color: "#fff" },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { height: 36, paddingHorizontal: 14, borderRadius: 999, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, justifyContent: "center" },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipTx: { fontFamily: F.bm, fontSize: 14, color: C.fg },
  badge: { flexDirection: "row", alignItems: "center", gap: 6 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  card: { backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 16, padding: 16 },
  stat: { flex: 1, backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 16, padding: 12 },
  statN: { fontFamily: F.d8, fontSize: 28, color: C.fg },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  item: { width: "47.5%", flexGrow: 1, backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 16, overflow: "hidden" },
  itemT: { fontFamily: F.d6, fontSize: 15, color: C.fg },
  iconBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: C.card, alignItems: "center", justifyContent: "center" },
  drop: { aspectRatio: 4 / 5, borderRadius: 16, borderWidth: 1.5, borderStyle: "dashed", borderColor: C.accent, backgroundColor: C.accentSoft, alignItems: "center", justifyContent: "center" },
  photo: { aspectRatio: 1, borderRadius: 16, overflow: "hidden", backgroundColor: C.bg2, borderColor: C.line, borderWidth: 1 },
  banner: { backgroundColor: C.accentSoft, borderColor: C.line, borderWidth: 1, borderRadius: 12, padding: 12 },
  input: { height: 52, borderRadius: 12, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, color: C.fg, paddingHorizontal: 14, fontFamily: F.b, fontSize: 16 },
  tabs: { flexDirection: "row", borderTopWidth: 1, borderTopColor: C.line, backgroundColor: C.bg },
  tab: { flex: 1, minHeight: 56, alignItems: "center", justifyContent: "center", gap: 2 },
  toast: { position: "absolute", left: 16, right: 16, backgroundColor: C.fg, padding: 12, borderRadius: 12 },
  obArt: { width: "100%", aspectRatio: 1, maxHeight: 320, borderRadius: 24, backgroundColor: C.card },
  obBox: { width: 120, height: 120, borderRadius: 28, borderWidth: 5, borderColor: C.accentHi },
  pg: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.line },
  pgOn: { width: 22, backgroundColor: C.accentHi },
});
